# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['fastapi_mock']
install_requires = \
['fastapi>=0.49.0,<0.50.0',
 'japanize-matplotlib>=1.0.5,<2.0.0',
 'matplotlib>=3.1.3,<4.0.0',
 'numpy>=1.18.1,<2.0.0',
 'pandas>=1.0.1,<2.0.0',
 'seaborn>=0.10.0,<0.11.0',
 'uvicorn>=0.11.3,<0.12.0']

setup_kwargs = {
    'name': 'fastapi-mock',
    'version': '0.1.0',
    'description': 'testing python package',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
